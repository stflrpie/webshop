const scheduler = require("node-schedule");
const moment = require("moment");
const { Sculpture, LookAtUser } = require("../models");
const { emailService } = require("../services");
const config = require("../config/config");
const axios = require("axios");
const { child } = require("winston");

const updateSculptureStatus = () => {
  //   return scheduler.scheduleJob("*/10 * * * * *", async () => {
  return scheduler.scheduleJob("*/5 * * * *", async () => {
    // console.log("inside updateSculptureStatus");
    const scultpures = await Sculpture.find({});
    const currentDate = Date.now();

    function getDifferenceInMinutes(currentDate, specificDate) {
      const differenceInMilliseconds = Math.abs(specificDate - currentDate);
      return Math.round(differenceInMilliseconds / (1000 * 60));
    }

    const asyncForEach = async (arr, callback) => {
      // eslint-disable-next-line
      for (let i = 0; i < arr.length; i++) {
        // eslint-disable-next-line
        await callback(arr[i]);
      }
    };

    const checkStatus = async () => {
      await asyncForEach(scultpures, async (sculpture) => {
        const { activity } = sculpture;
        const getdiff = getDifferenceInMinutes(currentDate, activity.updatedAt);
        if (getdiff > 5) {
          if (activity.status == "Active") {
            await Sculpture.updateOne(
              { _id: sculpture._id },
              { "activity.status": "Offline" }
            );
          } else if (activity.status == "Online") {
            await Sculpture.updateOne(
              { _id: sculpture._id },
              { "activity.status": "Active" }
            );
          }
        }
      });
    };

    await checkStatus();
  });
};

// const checkDeviceStatusAndSendMail = () => {
//   return scheduler.scheduleJob("*/10 * * * * *", async () => {
//     const token = config.deviceAccessToken;
//     const url = `https://rms.teltonika-networks.com/api/devices`;
//     const getData = await axios
//       .get(url, {
//         headers: {
//           Authorization: `Bearer ${token}`,
//         },
//       })
//       .then((response) => {
//         return response.data;
//       })
//       .catch((error) => {
//         throw error;
//       });
//     const currentDate = Date.now();
//     function getDifferenceInMinutes(currentDate, specificDate) {
//       const differenceInMilliseconds = Math.abs(specificDate - currentDate);
//       return Math.round(differenceInMilliseconds / (1000 * 60));
//     }
//     const asyncForEach = async (arr, callback) => {
//       // eslint-disable-next-line
//       for (let i = 0; i < arr.length; i++) {
//         // eslint-disable-next-line
//         await callback(arr[i]);
//       }
//     };
//     const checkStatus = async () => {
//       await asyncForEach(getData.data, async (data) => {
//         if (data.status === 0) {
//           console.log("data", data.id, data.status);
//         }
//         // if (getdiff > 5) {
//         //   if (activity.status == "Active") {
//         //   } else if (activity.status == "Online") {
//         //   }
//         // }
//       });
//     };
//     await checkStatus();
//   });
// };

const dailyStatsMailSend = () => {
  //   return scheduler.scheduleJob("55 23 * * * *", async () => {
  return scheduler.scheduleJob("0 22 * * *", async () => {
    // return scheduler.scheduleJob("*/2 * * * *", async () => {
    // const fromDate = new Date();
    // fromDate.setHours(0, 0, 0, 0); // Set to midnight
    // const toDate = new Date();
    // toDate.setHours(23, 59, 59, 999); // Set to end of day

    const fromDate = new Date();
    const toDate = new Date();
    // const fromDate = new Date("2024-01-12T18:30:00.000Z");
    // const toDate = new Date("2024-03-13T18:29:59.999Z");
    const date = fromDate.toDateString();

    const scultpures = await Sculpture.find({});

    const asyncForEach = async (arr, callback) => {
      // eslint-disable-next-line
      for (let i = 0; i < arr.length; i++) {
        // eslint-disable-next-line
        await callback(arr[i]);
      }
    };
    const dailyStats = [];
    const checkDailyStats = async () => {
      await asyncForEach(scultpures, async (sculpture) => {
        const { sculptureId, name } = sculpture;
        let scultpureInfo = {
          name: name,
          totalUsers: 0, // Initialize these properties
          totalNewPhotos: 0,
          totalEmailSent: 0,
        };
        // console.log("sculptureId", sculptureId);
        const totalUsers = await LookAtUser.find({
          CreateDate: {
            $gte: fromDate,
            $lte: toDate,
          },
          SculptureID: sculptureId,
          // IsEmailSent: true,
        });
        const getTotalEmailSent = await LookAtUser.find({
          CreateDate: {
            $gte: fromDate,
            $lte: toDate,
          },
          SculptureID: sculptureId,
          IsEmailSent: true,
        });
        scultpureInfo.name = name;
        scultpureInfo.totalUsers = totalUsers.length;
        scultpureInfo.totalNewPhotos = totalUsers.length; // You might want to update this based on actual logic
        scultpureInfo.totalEmailSent = getTotalEmailSent.length;
        // console.log("length", totalUsers.length);
        dailyStats.push(scultpureInfo);
      });
    };

    await checkDailyStats();

    // console.log("dailyStats", dailyStats);
    const mailOptions = emailService.sendDailyStatsMail(dailyStats, date);
    emailService.sendHtmlEmail(
      mailOptions.to,
      mailOptions.subject,
      mailOptions.html
    );
    // function getDifferenceInMinutes(currentDate, specificDate) {
    //   const differenceInMilliseconds = Math.abs(specificDate - currentDate);
    //   return Math.round(differenceInMilliseconds / (1000 * 60));
    // }
  });
};

module.exports = {
  updateSculptureStatus,
  // checkDeviceStatusAndSendMail,
  dailyStatsMailSend,
};
