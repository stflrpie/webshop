const braintree = require("braintree");
const config = require("../config/config");

const braintreeGateway = new braintree.BraintreeGateway({
  environment: braintree.Environment.Sandbox,
  merchantId: config.merchantId,
  publicKey: config.publicKey,
  privateKey: config.privateKey,
});

module.exports = { braintreeGateway };
