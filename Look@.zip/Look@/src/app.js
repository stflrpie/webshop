const express = require("express");
const helmet = require("helmet");
const xss = require("xss-clean");
const mongoSanitize = require("express-mongo-sanitize");
const compression = require("compression");
const cors = require("cors");
// const httpStatus = require("http-status");
const passport = require("passport");
const config = require("./config/config");
const morgan = require("./config/morgan");
const session = require("express-session");
const { jwtStrategy } = require("./config/passport");
const {
  updateSculptureStatus,
  // checkDeviceStatusAndSendMail,
  dailyStatsMailSend,
} = require("./config/schedule");
const routesV1 = require("./routes/v1");
// const routesV2 = require("./routes/v2");
const { errorConverter, errorHandler } = require("./middlewares/error");
// const ApiError = require("./utils/ApiError");
const app = express();

const memoryStore = new session.MemoryStore();
app.use(
  session({
    secret:
      "But they never did, ever lived, ebbing and flowing Inhibited, limited 'til it broke open and rained down",
    resave: false,
    saveUninitialized: true,
    store: memoryStore,
  })
);

if (config.env !== "test") {
  app.use(morgan.successHandler);
  app.use(morgan.errorHandler);
}

// set security HTTP headers
app.use(helmet());

// parse urlencoded request body
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// sanitize request data
app.use(xss());
app.use(mongoSanitize());

// gzip compression
app.use(compression());

// enable cors
app.use(cors());
app.options("*", cors());

// jwt authentication
app.use(passport.initialize());
passport.use("jwt", jwtStrategy);

// crone-jobs
updateSculptureStatus();
// checkDeviceStatusAndSendMail();
dailyStatsMailSend();

// v1 api routes
app.use("/v1", routesV1);

// v2 api routes
// app.use("/v2", routesV2);

// convert error to ApiError, if needed
app.use(errorConverter);

// handle error
app.use(errorHandler);

module.exports = app;
