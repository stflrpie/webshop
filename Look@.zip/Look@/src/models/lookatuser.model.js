const mongoose = require("mongoose");
const validator = require("validator");
const { paginate } = require("./plugins");
const lookat = mongoose.connection.useDb(`LookAt`);

const lookatuserSchema = new mongoose.Schema(
  {
    SculptureID: {
      type: String,
    },
    UserId: {
      type: String,
    },
    Photos: {
      type: String,
    },
    Email: {
      type: String,
      validate(value) {
        if (!validator.isEmail(value)) {
          throw new Error("Invalid email");
        }
      },
    },
    CreateDate: {
      type: Date,
      default: Date.now(),
    },
    ModifyDate: {
      type: Date,
      default: Date.now(),
    },
    IsEmailSent: {
      type: Boolean,
    },
  },
  { collection: "LookAtUser" }
  //   {
  //     timestamps: true,
  //   }
);

// add plugin that converts mongoose to json
// adminSchema.plugin(toJSON)
lookatuserSchema.plugin(paginate);

const LookAtUser = lookat.model("LookAtUser", lookatuserSchema);

module.exports = LookAtUser;
