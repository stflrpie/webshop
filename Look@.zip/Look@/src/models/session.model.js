const mongoose = require("mongoose");
const validator = require("validator");
const { paginate } = require("./plugins");
const lookat = mongoose.connection.useDb(`LookAt`);

const sessionSchema = new mongoose.Schema(
  {
    sculptureId: {
      type: String,
      required: true,
      // unique: false,
    },
    userId: {
      type: String,
      // required: true,
    },
    photos: {
      type: String,
      // required: true,
    },
    email: {
      type: String,
      // required: true,
      validate(value) {
        if (!validator.isEmail(value)) {
          throw new Error("Invalid email");
        }
      },
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
// adminSchema.plugin(toJSON)
sessionSchema.plugin(paginate);

const Session = lookat.model("Session", sessionSchema);

module.exports = Session;
