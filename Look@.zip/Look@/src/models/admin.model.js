const mongoose = require("mongoose");
const validator = require("validator");
const bcrypt = require("bcryptjs");
const { paginate } = require("./plugins");
const config = require("../config/config");
const lookat = mongoose.connection.useDb(`LookAt`);

const adminSchema = new mongoose.Schema(
  {
    firstName: {
      type: String,
      required: true,
    },
    lastName: {
      type: String,
      required: true,
    },
    username: {
      type: String,
      required: true,
    },
    userId: {
      type: String,
      required: true,
    },
    password: {
      type: String,
      required: true,
      trim: true,
      minlength: 8,
      validate(value) {
        if (!value.match(/\d/) || !value.match(/[a-zA-Z]/)) {
          throw new Error(
            "Password must contain at least one letter and one number"
          );
        }
      },
      private: true, // used by the toJSON plugin
    },
    title: {
      type: String,
      //   required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
      validate(value) {
        if (!validator.isEmail(value)) {
          throw new Error("Invalid email");
        }
      },
    },
    mobile: {
      type: String,
    },
    street: {
      type: String,
    },
    state: {
      type: String,
    },
    timezone: {
      type: String,
    },
    zipcode: {
      type: String,
    },
    country: {
      type: String,
    },
    profilePicture: {
      type: Object,
      default: null,
    },
    archive: {
      type: Boolean,
      default: false,
    },
    lastActive: {
      type: Date,
    },
    verified: {
      type: Boolean,
      default: false,
    },
    type: {
      type: String,
      ref: "Admin",
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
// adminSchema.plugin(toJSON)
adminSchema.plugin(paginate);

/**
 * Check if password matches the user's password
 * @param {string} password
 * @returns {Promise<boolean>}
 */
adminSchema.methods.isPasswordMatch = async function (password) {
  const user = this;
  return bcrypt.compare(password, user.password);
};

/**
 * Check if email is taken
 * @param {string} email - The user's email
 * @param {ObjectId} [excludeUserId] - The id of the user to be excluded
 * @returns {Promise<boolean>}
 */
adminSchema.statics.isEmailTaken = async function (email, excludeUserId) {
  const user = await this.findOne({ email, _id: { $ne: excludeUserId } });
  return !!user;
};

adminSchema.pre("save", async function (next) {
  const user = this;
  if (user.isModified("password")) {
    user.password = await bcrypt.hash(user.password, 8);
  }
  next();
});

/**
 * @typedef User
 */

const Admin = lookat.model("Admin", adminSchema);

module.exports = Admin;
