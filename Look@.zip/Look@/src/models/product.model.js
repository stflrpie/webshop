const mongoose = require("mongoose");
const { paginate } = require("./plugins");
const lookat = mongoose.connection.useDb(`LookAt`);

const priceSchema = new mongoose.Schema({
  value: { type: Number, required: true },
  currency: { type: String, required: true },
});

const productSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      unique: true,
    },
    clientModel: {
      type: Boolean,
      default: true,
    },
    prices: [
      {
        country: { type: String, required: true },
        price: priceSchema,
      },
    ],
    images: {
      type: Array,
      default: [],
    },
    sizes: {
      type: Array,
      default: [],
    },
    color: {
      type: Array,
      default: [],
    },
    shippingMethod: {
      type: Array,
      default: [],
    },
    active: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

productSchema.plugin(paginate);

const Product = lookat.model("Product", productSchema);

module.exports = Product;
