const mongoose = require("mongoose");
const { toJSON } = require("./plugins");

const lookat = mongoose.connection.useDb(`LookAt`);

const IdSchema = new mongoose.Schema({
  adId: {
    type: Number,
    default: 100100,
  },
  laId: {
    type: Number,
    default: 100100,
  },
});

// add plugin that converts mongoose to json
IdSchema.plugin(toJSON);

/**
 * @typedef Token
 */

const RandomIds = lookat.model("RandomIds", IdSchema);

module.exports = RandomIds;
