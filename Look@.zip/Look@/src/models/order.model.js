const mongoose = require("mongoose");
const { paginate } = require("./plugins");
const lookat = mongoose.connection.useDb(`LookAt`);

const orderSchema = new mongoose.Schema(
  {
    transactionId: {
      type: String,
      required: true,
      unique: true,
    },
    productId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Product",
    },
    productInfo: {
      type: Array,
      default: [],
    },
    email: {
      type: String,
      //   validate(value) {
      //     if (!validator.isEmail(value)) {
      //       throw new Error("Invalid email");
      //     }
      //   },
    },
    phone: {
      type: String,
    },
    address: {
      type: String,
      max: 50,
      min: 2,
    },
    city: {
      type: String,
      max: 30,
      min: 2,
    },
    state: {
      type: String,
      max: 30,
      min: 2,
    },
    country: {
      type: String,
      max: 30,
      min: 2,
    },
    pincode: {
      type: String,
      max: 6,
      min: 2,
    },
    amount: {
      type: Number,
      default: 0,
    },
    status: {
      type: String,
    },
    paymentStatus: {
      type: String,
      enum: ["Pending", "Completed", "Failed"],
      default: "Pending",
    },
    deliveryStatus: {
      type: String,
      enum: ["Pending", "Shipped", "In Transit", "Delivered"],
      default: "Pending",
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
// adminSchema.plugin(toJSON)
orderSchema.plugin(paginate);

const Order = lookat.model("Order", orderSchema);

module.exports = Order;
