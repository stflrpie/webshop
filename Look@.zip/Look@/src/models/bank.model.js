const mongoose = require("mongoose");
const { paginate } = require("./plugins");
const lookat = mongoose.connection.useDb(`LookAt`);

const bankSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true,
    },
    icon: {
      type: String,
      required: true,
    },
    status: {
      type: Boolean,
      required: true,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

bankSchema.plugin(paginate);

const Bank = lookat.model("Bank", bankSchema);

module.exports = Bank;
