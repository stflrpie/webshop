const mongoose = require("mongoose");
const { paginate } = require("./plugins");
const lookat = mongoose.connection.useDb(`LookAt`);

const sculptureSchema = new mongoose.Schema(
  {
    sculptureId: {
      type: String,
      required: true,
      unique: true,
    },
    name: {
      type: String,
      required: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "Admin",
    },
    location: {
      type: String,
      required: true,
    },
    street: {
      type: String,
    },
    pincode: {
      type: Number,
    },
    activity: {
      status: { type: String, enum: ["Online", "Offline", "Deactivated"] },
      updatedAt: {
        type: Date,
        default: Date.now(),
      },
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
// adminSchema.plugin(toJSON)
sculptureSchema.plugin(paginate);

const Sculpture = lookat.model("Sculpture", sculptureSchema);

module.exports = Sculpture;
