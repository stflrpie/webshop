const express = require("express");
const { adminController } = require("../../controllers");
const auth = require("../../middlewares/auth");

const router = express.Router();

router.get(
  "/getsessionfromuserid/:id",
  adminController.getSessionInfoFromUserId
);

router.post("/addsession", adminController.addSessionInfo);

router.post("/addsculptures", auth(), adminController.addSculptures);

router.get("/getallsculptures", auth(), adminController.getAllSculptures);

router.get("/getsculptureinfo/:id", auth(), adminController.getSculptureInfo);

router.get(
  "/getsculpturesphotos/:id",
  auth(),
  adminController.getSculpturesPhoto
);

router.get("/getprofileinfo", auth(), adminController.getProfileInfo);

// test
router.get("/getlookatinfo/:id", auth(), adminController.getLookAtInfo);

//kpi
router.get("/totalnewusers", auth(), adminController.getTotalNewUsers);
router.get("/totalnewphotos", auth(), adminController.getTotalNewPhotos);
router.get("/totalemailsent", auth(), adminController.getTotalEmailSent);

module.exports = router;
