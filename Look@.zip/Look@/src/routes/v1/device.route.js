const express = require("express");
const { deviceController } = require("../../controllers");
const auth = require("../../middlewares/auth");

const router = express.Router();

router.get("/getalldevices", auth(), deviceController.devices);

router.get("/devices/:id", auth(), deviceController.deviceId);

router.get("/alldeviceslogs", auth(), deviceController.allDeviceLogs);

router.get("/devicelogs/:id", auth(), deviceController.deviceLogs);

router.get("/allalerts", auth(), deviceController.allAlerts);

router.get("/getdevicealerts/:id", auth(), deviceController.deviceAlerts);

module.exports = router;
