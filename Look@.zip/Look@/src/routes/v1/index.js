const express = require("express");
const adminRoute = require("./admin.route");
const authRoute = require("./auth.route");
const sculptureRoute = require("./sculpture.route");
const deviceRoute = require("./device.route");
const productRoute = require("./product.route");
const orderRoute = require("./order.route");

const router = express.Router();

const defaultRoutes = [
  {
    path: "/admin",
    route: adminRoute,
  },
  {
    path: "/auth",
    route: authRoute,
  },
  {
    path: "/sculpture",
    route: sculptureRoute,
  },
  {
    path: "/device",
    route: deviceRoute,
  },
  {
    path: "/product",
    route: productRoute,
  },
  {
    path: "/order",
    route: orderRoute,
  },
];

defaultRoutes.forEach((route) => {
  router.use(route.path, route.route);
});

module.exports = router;
