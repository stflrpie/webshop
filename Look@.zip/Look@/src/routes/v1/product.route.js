const express = require("express");
const { productController } = require("../../controllers");
const auth = require("../../middlewares/auth");

const router = express.Router();

router.post("/createproduct", auth(), productController.createProduct);

router.get("/getproductslist", productController.getProductList);

router.get("/getproductinfo/:id", productController.getProductInfo);

router.post("/updateproduct/:id", auth(), productController.updateProduct);

router.delete("/deleteproduct/:id", auth(), productController.deleteProduct);

router.post("/getimagefromemail", productController.getImageFromEmail);

module.exports = router;
