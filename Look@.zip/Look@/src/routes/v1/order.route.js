const express = require("express");
const { orderController } = require("../../controllers");
const auth = require("../../middlewares/auth");

const router = express.Router();

router.get("/client_token", orderController.getClientToken);

router.post("/checkout", orderController.checkoutProduct);

router.post("/createorder", orderController.createOrder);

router.get("/getAllOrders", orderController.getAllOrders);

router.get("/getorder/:id", orderController.getOrderInfo);

router.patch(
  "/updatedeliverystatus/:id",
  auth(),
  orderController.updateDeliveryStatus
);

router.post("/addbank", auth(), orderController.addBank);
router.get("/getbanks", orderController.getBanks);

module.exports = router;
