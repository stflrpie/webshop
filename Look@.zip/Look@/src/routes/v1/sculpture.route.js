const express = require("express");
const { sculptureController } = require("../../controllers");

const router = express.Router();

router.post("/updateStatus/:id", sculptureController.updateStatus);

module.exports = router;
