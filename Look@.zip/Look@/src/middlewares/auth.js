const jwt = require("jsonwebtoken");
const httpStatus = require("http-status");
const ApiError = require("../utils/ApiError");
const config = require("../config/config");
// const { userService } = require("../services");

const verifyCallback = (req, resolve, reject) => async (err, user, info) => {
  if (err || info || !user) {
    return reject(new ApiError(httpStatus.UNAUTHORIZED, "Please authenticate"));
  }
  req.user = user;

  resolve();
};

const auth = (requiredRights) => async (req, res, next) => {
  return new Promise((resolve, reject) => {
    // const key = `-----BEGIN PUBLIC KEY-----\n${config.jwt.secret}\n-----END PUBLIC KEY-----`;
    const key = config.jwt.secret;
    if (!req.header("Authorization")) {
      return reject(
        new ApiError(httpStatus.UNAUTHORIZED, "Please authenticate")
      );
    }
    const token = req.header("Authorization").replace("Bearer ", "");
    jwt.verify(token, key, verifyCallback(req, resolve, reject))(
      req,
      res,
      next
    );
  })
    .then(async () => {
      next();
    })
    .catch((err) => next(err));
};

module.exports = auth;
