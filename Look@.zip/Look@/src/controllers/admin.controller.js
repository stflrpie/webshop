const Cryptr = require("cryptr");
const httpStatus = require("http-status");
const config = require("../config/config");
const ApiError = require("../utils/ApiError");
const catchAsync = require("../utils/catchAsync");
const pick = require("../utils/pick");
const { userService, adminService } = require("../services");
const { Sculpture, Session, LookAtUser, LookAtAdmin } = require("../models");

const cryptr = new Cryptr(config.cryptr);

const getSessionInfoFromUserId = catchAsync(async (req, res) => {
  const session = await LookAtUser.findOne({ UserId: req.params.id });
  res.send({
    message: "success",
    payload: session,
  });
});

const addSessionInfo = catchAsync(async (req, res) => {
  const { SculptureID, UserId, Photos, Email, IsEmailSent } = req.body;
  const session = await LookAtUser.create({
    SculptureID,
    UserId,
    Photos,
    Email,
    IsEmailSent,
  });
  res.send({
    message: "success",
    payload: {
      session,
    },
  });
});

const addSculptures = catchAsync(async (req, res) => {
  const user = await userService.getUserById(req.user.sub);
  const sculptureBody = {
    ...req.body,
    createdBy: user._id,
  };
  const created = await Sculpture.create(sculptureBody);
  return res
    .status(httpStatus.CREATED)
    .send({ success: true, payload: created });
});

const getAllSculptures = catchAsync(async (req, res) => {
  const filterQuery = await adminService.getFilterQuery(req.query, req.params);
  const filter = pick(
    {
      ...filterQuery[0],
    },
    [...filterQuery[1]]
  );
  const options = pick(req.query, ["sortBy", "limit", "page"]);
  let sculptures = await Sculpture.paginate(filter, {
    ...options,
  });
  return res
    .status(httpStatus.CREATED)
    .send({ success: true, payload: sculptures });
});

const getSculptureInfo = catchAsync(async (req, res) => {
  const sculpture = await Sculpture.findById(req.params.id);
  return res.status(httpStatus.OK).send({ success: true, payload: sculpture });
});

const getProfileInfo = catchAsync(async (req, res) => {
  const user = await userService.getUserById(req.user.sub);
  const userInfo = await LookAtAdmin.findById(user).select(" -password ");
  return res.status(httpStatus.OK).send({ success: true, payload: userInfo });
});

const getSculpturesPhoto = catchAsync(async (req, res) => {
  const sculpture = await Sculpture.findById(req.params.id);
  const filterQuery = await adminService.getFilterQuery(req.query, req.params);
  const filter = pick(
    {
      ...filterQuery[0],
      SculptureID: sculpture.sculptureId,
    },
    [...filterQuery[1], "SculptureID"]
  );
  const options = pick(req.query, ["sortBy", "limit", "page"]);
  let sculptures = await LookAtUser.paginate(filter, {
    ...options,
  });
  return res.status(httpStatus.OK).send({ success: true, payload: sculptures });
});

const getLookAtInfo = catchAsync(async (req, res) => {
  const session = await LookAtUser.find({ SculptureID: req.params.id });
  return res.status(httpStatus.OK).send({ success: true, payload: session });
});

const getTotalNewUsers = catchAsync(async (req, res) => {
  const filterQuery = await adminService.getFilterQuery(req.query, req.params);
  console.log("inside");
  const filter = pick({ ...filterQuery[0] }, [...filterQuery[1]]);
  console.log("filter", filter);
  // let user = await LookAtUser.find({ ...filter, Email: { $ne: null } });
  let user = await LookAtUser.find({ ...filter });
  return res
    .status(httpStatus.OK)
    .send({ success: true, payload: user.length });
});

const getTotalNewPhotos = catchAsync(async (req, res) => {
  const filterQuery = await adminService.getFilterQuery(req.query, req.params);

  const filter = pick({ ...filterQuery[0] }, [...filterQuery[1]]);

  let photos = await LookAtUser.find({ ...filter });
  return res
    .status(httpStatus.OK)
    .send({ success: true, payload: photos.length });
});

const getTotalEmailSent = catchAsync(async (req, res) => {
  const filterQuery = await adminService.getFilterQuery(req.query, req.params);

  const filter = pick({ ...filterQuery[0] }, [...filterQuery[1]]);

  let email = await LookAtUser.find({ ...filter, IsEmailSent: true });
  return res
    .status(httpStatus.OK)
    .send({ success: true, payload: email.length });
});

module.exports = {
  getSessionInfoFromUserId,
  addSessionInfo,
  addSculptures,
  getAllSculptures,
  getSculptureInfo,
  getSculpturesPhoto,
  getLookAtInfo,
  getProfileInfo,
  getTotalNewUsers,
  getTotalNewPhotos,
  getTotalEmailSent,
};
