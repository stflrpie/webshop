// const Cryptr = require("cryptr");
const httpStatus = require("http-status");
const catchAsync = require("../utils/catchAsync");
const {
  authService,
  userService,
  tokenService,
  emailService,
  registrationService,
} = require("../services");
const ApiError = require("../utils/ApiError");

// const cryptr = new Cryptr(config.cryptr);

const register = catchAsync(async (req, res) => {
  const { email, type } = req.body;
  await userService.checkUserByEmail(email);

  // GETTING USER SERIES ID
  const ids = await registrationService.updateRandomId(type);
  // const uuid = uuidv4();
  const userId = await registrationService.generateId(ids, type);

  const username = await registrationService.generateUsername();

  const userBody = userService.getUserBody(req.body, type, username, userId);

  const user = await userService.createUser(type, userBody);
  // const tokens = await tokenService.generateAuthTokens(user);
  // console.log("tokens", tokens);
  // res.status(httpStatus.CREATED).send({ user, tokens });
  res.send({
    success: true,
    message: "User registered successfully",
    payload: user,
  });
});

// Login controller.
const login = catchAsync(async (req, res) => {
  const { email, password } = req.body;
  const user = await authService.loginUserWithEmailAndPassword(email, password);
  if (!user.verified) {
    throw new ApiError(
      httpStatus.METHOD_NOT_ALLOWED,
      "User is not verified. Please check your registered email to find a verification link"
    );
  }
  if (user.status === "Rejected") {
    throw new ApiError(
      httpStatus.METHOD_NOT_ALLOWED,
      "Account is rejected by admin. Please contact support"
    );
  }

  const tokens = await tokenService.generateAuthTokens(user);

  res.send({
    success: true,
    message: "Logged in successfully",
    payload: {
      access_token: tokens.access.token,
      email: user.email,
      type: user.type,
      id: user.id,
      verified: user.verified,
    },
  });
});

const adminregister = catchAsync(async (req, res) => {
  const { email, type } = req.body;
  await userService.checkUserByEmail(email);

  // GETTING USER SERIES ID
  const ids = await registrationService.updateRandomId(type);
  // const uuid = uuidv4();
  const userId = await registrationService.generateId(ids, type);

  const username = await registrationService.generateUsername();

  const userBody = userService.getUserBody(req.body, type, username, userId);
  const user = await userService.createUser(type, userBody);
  res.send({
    success: true,
    message: "User registered successfully",
    payload: user,
  });
});

const adminLogin = catchAsync(async (req, res) => {
  const { email, password } = req.body;
  const user = await authService.loginAdminWithEmailAndPassword(
    email,
    password
  );
  if (!user.verified) {
    throw new ApiError(
      httpStatus.METHOD_NOT_ALLOWED,
      "User is not verified. Please check your registered email to find a verification link"
    );
  }

  const tokens = await tokenService.generateAuthTokens(user);

  res.send({
    success: true,
    message: "Logged in successfully",
    payload: {
      access_token: tokens.access.token,
      type: user.type,
      id: user.id,
      username: user.username,
      verified: true,
      profileCompleted: true,
    },
  });
});

module.exports = {
  register,
  login,
  adminregister,
  adminLogin,
};
