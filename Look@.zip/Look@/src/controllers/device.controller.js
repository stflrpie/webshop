const Cryptr = require("cryptr");
const httpStatus = require("http-status");
const config = require("../config/config");
const catchAsync = require("../utils/catchAsync");
const axios = require("axios");

const cryptr = new Cryptr(config.cryptr);

const devices = catchAsync(async (req, res) => {
  const limit = req.query.limit ? parseInt(req.query.limit, 10) : 10;
  const token = config.deviceAccessToken;
  const url = `https://rms.teltonika-networks.com/api/devices?limit=${limit}`;
  const getData = await axios
    .get(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      throw error;
    });
  return res.status(httpStatus.OK).send({ success: true, payload: getData });
});

const deviceId = catchAsync(async (req, res) => {
  const id = req.params.id;
  const token = config.deviceAccessToken;
  const url = `https://rms.teltonika-networks.com/api/devices/${id}`;
  const getDevice = await axios
    .get(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      throw error;
    });
  return res.status(httpStatus.OK).send({ success: true, payload: getDevice });
});

const allDeviceLogs = catchAsync(async (req, res) => {
  const limit = req.query.limit ? parseInt(req.query.limit, 10) : 10;
  const token = config.deviceAccessToken;
  const url = `https://rms.teltonika-networks.com/api/devices/logs?limit=${limit}`;
  const getData = await axios
    .get(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      throw error;
    });
  return res.status(httpStatus.OK).send({ success: true, payload: getData });
});

const deviceLogs = catchAsync(async (req, res) => {
  const limit = req.query.limit ? parseInt(req.query.limit, 10) : 10;
  const id = req.params.id;
  const token = config.deviceAccessToken;
  const url = `https://rms.teltonika-networks.com/api/devices/${id}/logs?limit=${limit}`;
  const getDevice = await axios
    .get(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      throw error;
    });
  return res.status(httpStatus.OK).send({ success: true, payload: getDevice });
});

const allAlerts = catchAsync(async (req, res) => {
  const limit = req.query.limit ? parseInt(req.query.limit, 10) : 10;
  const token = config.deviceAccessToken;
  const url = `https://rms.teltonika-networks.com/api/alerts?limit=${limit}`;
  const getData = await axios
    .get(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      throw error;
    });
  return res.status(httpStatus.OK).send({ success: true, payload: getData });
});

const deviceAlerts = catchAsync(async (req, res) => {
  const limit = req.query.limit ? parseInt(req.query.limit, 10) : 10;
  const id = req.params.id;
  const token = config.deviceAccessToken;
  const url = `https://rms.teltonika-networks.com/api/alerts/${id}?limit=${limit}`;
  const getDevice = await axios
    .get(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      throw error;
    });
  return res.status(httpStatus.OK).send({ success: true, payload: getDevice });
});

module.exports = {
  devices,
  deviceId,
  allDeviceLogs,
  deviceLogs,
  allAlerts,
  deviceAlerts,
};
