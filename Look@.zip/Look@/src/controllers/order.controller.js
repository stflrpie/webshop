const { braintreeGateway } = require("../config/braintree");
const httpStatus = require("http-status");
const config = require("../config/config");
const catchAsync = require("../utils/catchAsync");
const { Order, Product, Bank } = require("../models");
const ApiError = require("../utils/ApiError");
const { emailService, orderService } = require("../services");
const pick = require("../utils/pick");

const getClientToken = catchAsync(async (req, res) => {
  braintreeGateway.clientToken.generate({}, (err, response) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.send(response.clientToken);
    }
  });
});

const checkoutProduct = catchAsync(async (req, res) => {
  const nonceFromTheClient = req.body.paymentMethodNonce;
  const { amount } = req.body;

  braintreeGateway.transaction.sale(
    {
      amount: amount,
      paymentMethodNonce: nonceFromTheClient,
      options: {
        submitForSettlement: true,
      },
    },
    (err, result) => {
      if (err) {
        res.status(500).send(err);
      } else {
        res.send(result);
      }
    }
  );
});

const createOrder = catchAsync(async (req, res) => {
  const { email, productId, amount } = req.body;
  await Order.create({ ...req.body });
  const product = await Product.findOne({
    _id: productId,
    active: true,
  }).lean();

  const mailOptions = emailService.sendOrderConfirmationMail(
    email,
    product,
    amount
  );
  emailService.sendHtmlEmail(
    mailOptions.to,
    mailOptions.subject,
    mailOptions.html
  );

  return res
    .status(httpStatus.OK)
    .send({ success: true, payload: "Order Placed Successfully" });
});

const getAllOrders = catchAsync(async (req, res) => {
  const filterQuery = await orderService.getFilterQuery(req.query, req.params);
  const filter = pick(
    {
      ...filterQuery[0],
    },
    [...filterQuery[1]]
  );
  const populate = [["productId", Product]];
  const options = pick(req.query, ["sortBy", "limit", "page"]);
  let orders = await Order.paginate(filter, {
    ...options,
    populate,
  });
  return res
    .status(httpStatus.CREATED)
    .send({ success: true, payload: orders });
});

const getOrderInfo = catchAsync(async (req, res) => {
  const order = await Order.findById(req.params.id).populate({
    path: "productId",
    model: Product,
    select: "transactionId",
  });
  if (!order) {
    return res
      .status(httpStatus.NOT_FOUND)
      .json({ success: false, message: "Order not found." });
  }
  return res.status(httpStatus.OK).send({ success: true, payload: order });
});

const updateDeliveryStatus = catchAsync(async (req, res) => {
  const { deliveryStatus } = req.body;
  const orderId = req.params.id;

  const validDeliveryStatus = ["Pending", "Shipped", "In Transit", "Delivered"];
  if (!validDeliveryStatus.includes(deliveryStatus)) {
    return res
      .status(httpStatus.BAD_REQUEST)
      .json({ success: false, message: "Invalid delivery status." });
  }

  const updatedOrder = await Order.findByIdAndUpdate(
    orderId,
    { $set: { deliveryStatus: deliveryStatus } },
    { new: true }
  );
  console.log("updatedOrder", updatedOrder.email);

  const mailOptions = emailService.sendDeliveryStatusMail(
    updatedOrder.email,
    deliveryStatus
  );
  console.log("mailOptions", mailOptions);

  emailService.sendHtmlEmail(
    mailOptions.to,
    mailOptions.subject,
    mailOptions.html
  );

  if (!updatedOrder) {
    return res
      .status(httpStatus.NOT_FOUND)
      .json({ success: false, message: "Order not found." });
  }

  return res
    .status(httpStatus.OK)
    .json({ success: true, payload: updatedOrder });
});

const addBank = catchAsync(async (req, res) => {
  try {
    // Extract gateways array from request body
    const { gateways } = req.body;

    // Loop through each gateway and create a new document in the Bank collection
    for (const gateway of gateways) {
      const newBank = new Bank({
        name: gateway.name,
        icon: gateway.icon,
      });

      await newBank.save(); // Save the new bank document to the database
    }

    return res
      .status(httpStatus.CREATED)
      .send({ success: true, message: "Bank Added Successfully" });
  } catch (err) {
    console.error("Error adding banks:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

const getBanks = catchAsync(async (req, res) => {
  const filterQuery = await orderService.getFilterQuery(req.query, req.params);
  const filter = pick({ ...filterQuery[0], status: true }, [
    ...filterQuery[1],
    "status",
  ]);
  const options = pick(req.query, ["sortBy", "limit", "page"]);
  let banks = await Bank.paginate(filter, {
    ...options,
  });
  return res.status(httpStatus.OK).send({ success: true, payload: banks });
});

module.exports = {
  getClientToken,
  checkoutProduct,
  createOrder,
  getAllOrders,
  getOrderInfo,
  updateDeliveryStatus,
  addBank,
  getBanks,
};
