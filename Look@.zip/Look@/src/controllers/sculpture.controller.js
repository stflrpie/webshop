const Cryptr = require("cryptr");
const httpStatus = require("http-status");
const config = require("../config/config");
const catchAsync = require("../utils/catchAsync");
const { Sculpture } = require("../models");

const cryptr = new Cryptr(config.cryptr);

const updateStatus = catchAsync(async (req, res) => {
  await Sculpture.updateOne(
    { sculptureId: req.params.id },
    { $set: { "activity.status": "Online", "activity.updatedAt": Date.now() } }
  );
  return res
    .status(httpStatus.OK)
    .send({ success: true, payload: "Status Updated" });
});

module.exports = {
  updateStatus,
};
