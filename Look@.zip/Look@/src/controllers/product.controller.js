const Cryptr = require("cryptr");
const httpStatus = require("http-status");
const config = require("../config/config");
const catchAsync = require("../utils/catchAsync");
const { Product, LookAtUser } = require("../models");
const ApiError = require("../utils/ApiError");

const cryptr = new Cryptr(config.cryptr);

const createProduct = catchAsync(async (req, res) => {
  const { title } = req.body;
  const productCheckExist = await Product.find({ title: title, active: true });
  if (productCheckExist.length !== 0) {
    throw new ApiError(
      httpStatus.METHOD_NOT_ALLOWED,
      "Product with this title already exists!"
    );
  }
  await Product.create(req.body);
  return res
    .status(httpStatus.OK)
    .send({ success: true, payload: "Product Created Successfully" });
});

const getProductList = catchAsync(async (req, res) => {
  const products = await Product.find({ active: true });
  return res.status(httpStatus.OK).send({ success: true, payload: products });
});

const getProductInfo = catchAsync(async (req, res) => {
  const products = await Product.find({ _id: req.params.id, active: true });
  if (!products) {
    throw new ApiError(
      httpStatus.METHOD_NOT_ALLOWED,
      "Product does not exists!"
    );
  }
  return res.status(httpStatus.OK).send({ success: true, payload: products });
});

const updateProduct = catchAsync(async (req, res) => {
  const productId = req.params.id;
  // const { title, prices, images, sizes } = req.body;

  // const updateObj = {
  //   $set: {
  //     title: title,
  //     prices: prices,
  //     images: images,
  //     sizes: sizes,
  //   },
  // };
  await Product.updateOne({ _id: productId }, { $set: { ...req.body } });
  return res
    .status(httpStatus.OK)
    .send({ success: true, payload: "Product Updated Successfully" });
});

const deleteProduct = catchAsync(async (req, res) => {
  const productId = req.params.id;
  const products = await Product.find({ _id: productId, active: true });
  if (!products) {
    throw new ApiError(
      httpStatus.METHOD_NOT_ALLOWED,
      "Product does not exists!"
    );
  } else {
    const updateObj = {
      $set: {
        active: false,
      },
    };
    await Product.updateOne({ _id: productId }, updateObj);
    return res
      .status(httpStatus.OK)
      .send({ success: true, payload: "Product Deleted Successfully" });
  }
});

const getImageFromEmail = catchAsync(async (req, res) => {
  const { email } = req.body;
  const getImage = await LookAtUser.find({ Email: email });
  if (!getImage) {
    throw new ApiError(httpStatus.METHOD_NOT_ALLOWED, "No Images found ");
  }
  return res.status(httpStatus.OK).send({ success: true, payload: getImage });
});

module.exports = {
  createProduct,
  getProductList,
  getProductInfo,
  updateProduct,
  deleteProduct,
  getImageFromEmail,
};
