module.exports.adminController = require("./admin.controller");
module.exports.authController = require("./auth.controller");
module.exports.sculptureController = require("./sculpture.controller");
module.exports.deviceController = require("./device.controller");
module.exports.productController = require("./product.controller");
module.exports.orderController = require("./order.controller");
