const httpStatus = require("http-status");
// const { default: axios } = require("axios");
// const config = require("../config/config");
const ApiError = require("../utils/ApiError");
// const logger = require("../config/logger");
const { Admin, LookAtAdmin } = require("../models");

const model = Object.freeze({
  ADMIN: Admin,
  LOOKATADMIN: LookAtAdmin,
});

const userIdType = Object.freeze({
  AD: Admin,
});

const role = Object.freeze({
  ADMIN: "admin",
  LOOKATADMIN: "super-admin",
});

const randomIds = Object.freeze({
  ADMIN: "adId",
  LOOKATADMIN: "laId",
});

/**
 * Create a user
 * @param {Object} userBody
 * @returns {Promise<User>}
 */

const createUser = async (type, userBody) => {
  if (await model[type].isEmailTaken(userBody.email)) {
    throw new ApiError(httpStatus.BAD_REQUEST, "Email already taken");
  }
  return model[type].create(userBody);
};

/**
 * Get user by email
 * @param {string} email
 * @returns {Promise<User>}
 */
const getUserByEmail = async (email) => {
  let user = await Admin.findOne({
    email,
  });

  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, "User not found");
  }
  return user;
};

/**
 * Get user by email
 * @param {string} email
 * @returns {Promise<User>}
 */
const getAdminByEmail = async (email) => {
  const user = await LookAtAdmin.findOne({
    email,
  });
  return user;
};

/**
 * Get user by email
 * @param {string} email
 * @returns {Promise<User>}
 */
const checkUserByEmail = async (email) => {
  let user = await Admin.findOne({
    email,
  });

  //   if (!user) {
  //     user = await LookAtAdmin.findOne({
  //       email,
  //     });
  //   }

  if (user) {
    throw new ApiError(httpStatus.BAD_REQUEST, "Email already exists in DB");
  }
  return user;
};

/**
 *
 * @param {*} userId
 * @param {*} updateBody
 * @returns
 */
const getRandomIdType = (type) => {
  return randomIds[type];
};

/**
 *
 * @param {object} body
 * @param {object} username
 * @returns
 */
const getObj = (...args) => {
  return {
    email: args[0].email,
    password: args[0].password,
    type: args[0].type,
    firstName: args[0].firstName,
    lastName: args[0].lastName,
    username: args[2],
    userId: args[3],
  };
};

/**
 *
 * @param {*} userId
 * @param {*} updateBody
 * @returns
 */
const getUserBody = (...args) => {
  return getObj(...args);
};

/**
 *
 * @param {*} userId
 * @param {*} updateBody
 * @returns
 */
const getUserByUsername = async (username) => {
  let user = await Admin.findOne({
    username,
  });

  //   if (!user) {
  //     user = await LookAtAdmin.findOne({
  //       email,
  //     });
  //   }

  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, "User not found");
  }
  return user;
};

/**
 * Get user by id
 * @param {ObjectId} id
 * @returns {Promise<User>}
 */
const getUserById = async (id) => {
  let user = await LookAtAdmin.findById(id);

  //   if (!user) {
  //     user = await LookAtAdmin.findById(id);
  //   }

  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, "User not found");
  }
  return user;
};

module.exports = {
  createUser,
  getUserByEmail,
  getAdminByEmail,
  checkUserByEmail,
  getRandomIdType,
  getUserBody,
  getUserByUsername,
  getUserById,
};
