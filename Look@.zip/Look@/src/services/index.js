module.exports.authService = require("./auth.service");
module.exports.emailService = require("./email.service");
module.exports.tokenService = require("./token.service");
module.exports.userService = require("./user.service");
module.exports.registrationService = require("./registration.service");
module.exports.adminService = require("./admin.service");
module.exports.orderService = require("./order.service");
