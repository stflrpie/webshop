const getFilterQuery = async (query) => {
  const { status, search, CreateDate, SculptureID } = query;
  let filter = {};
  if (status) {
    filter = { ...filter, status: { $in: status.split(",") } };
  }

  if (SculptureID) {
    filter = { ...filter, SculptureID: { $in: SculptureID.split(",") } };
  }

  if (CreateDate && CreateDate.from && CreateDate.to) {
    const fromDate = `${
      new Date(CreateDate.from).toISOString().split("T")[0]
    }T00:00:00.000Z`;
    const toDate = `${
      new Date(CreateDate.to).toISOString().split("T")[0]
    }T23:59:59.000Z`;
    filter = {
      ...filter,
      CreateDate: {
        $gte: fromDate,
        $lt: toDate,
      },
    };
  }
  if (CreateDate && CreateDate.from && !CreateDate.to) {
    filter = {
      ...filter,
      CreateDate: {
        $gte: CreateDate.from,
      },
    };
  }

  if (search) {
    filter = {
      ...filter,
      $or: [{ name: { $regex: search, $options: "i" } }],
    };
    // if (!Number.isNaN(Number(search))) {
    //   filter.$or.push({ experience: search });
    // }
  }
  return [filter, Object.keys(filter)];
};

module.exports = {
  getFilterQuery,
};
