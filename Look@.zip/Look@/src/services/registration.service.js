const Cryptr = require("cryptr");
const httpStatus = require("http-status");
const moment = require("moment");
const { RandomIds } = require("../models");
const config = require("../config/config");
const { userService } = require(".");
const ApiError = require("../utils/ApiError");

const cryptr = new Cryptr(config.cryptr);

const customIdFirstPair = Object.freeze({
  ADMIN: "AD",
  LOOKATADMIN: "LA",
});

/**
 * Update random id
 * @param {string} type
 * @returns {Promise<>}
 */
const updateRandomId = async (type) => {
  const name = userService.getRandomIdType(type);
  const ids = await RandomIds.findByIdAndUpdate("64cb6ce51ce4e21e0600f385", {
    $inc: { [name]: 1 },
  });
  if (!ids) {
    throw new ApiError(httpStatus.NOT_FOUND, "Id not found");
  }
  return ids;
};

/**
 * generate custom service id
 * @param {number} id
 * @returns {Promise<>}
 */
const generateId = (ids, type) => {
  const firstPair = customIdFirstPair[type];
  const secondPair = new Date().getFullYear().toString().slice(-2);
  const thirdPair = ids[userService.getRandomIdType(type)];

  return firstPair + secondPair + thirdPair;
};

const generateUsername = () => {
  var result = "";
  var chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  for (var i = 32; i > 0; --i) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
};

module.exports = {
  updateRandomId,
  generateId,
  generateUsername,
};
