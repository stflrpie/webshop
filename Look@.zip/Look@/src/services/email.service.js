const moment = require("moment");
const httpStatus = require("http-status");
const nodemailer = require("nodemailer");
const config = require("../config/config");
const logger = require("../config/logger");
const ApiError = require("../utils/ApiError");

const transport = nodemailer.createTransport(config.email.smtp);
/* istanbul ignore next */
// console.log("config", config.env);
// console.log("config", config.email.smtp);
if (config.env !== "test") {
  transport
    .verify()
    .then(() => logger.info("Connected to email server"))
    .catch((error) =>
      logger.warn(
        "Unable to connect to email server. Make sure you have configured the SMTP options in .env",
        error
      )
    );
}

/**
 * Send an email
 * @param {string} to
 * @param {string} subject
 * @param {string} text
 * @returns {Promise}
 */
const sendEmail = async (to, subject, text) => {
  const msg = { from: config.email.from, to, subject, text };
  await transport.sendMail(msg);
};

/**
 * Send an email with html
 * @param {string} to
 * @param {string} subject
 * @param {string} html
 * @returns {Promise}
 */
const sendHtmlEmail = async (to, subject, html, alternatives = null) => {
  const msg = { from: config.email.from, to, subject, html, alternatives };
  await transport.sendMail(msg);
};

const sendHtmlEmailWithCC = async (
  to,
  subject,
  html,
  cc,
  alternatives = null
) => {
  const msg = { from: config.email.from, to, subject, html, cc, alternatives };
  await transport.sendMail(msg);
};

const sendHtmlEmailWithPdf = async (to, subject, html, cc, attachments) => {
  const msg = { from: config.email.from, to, subject, html, cc, attachments };
  await transport.sendMail(msg);
};

const sendDailyStatsMail = (dailyStats, date) => {
  let htmlContent = `<h1>Daily Stats Update</h1><br>`;

  dailyStats.forEach((stat) => {
    htmlContent += `
        <p><strong>Name:</strong> ${stat.name}</p>
        <p><strong>Total Users:</strong> ${stat.totalUsers}</p>
        <p><strong>Total New Photos:</strong> ${stat.totalNewPhotos}</p>
        <p><strong>Total Email Sent:</strong> ${stat.totalEmailSent}</p>
        <br>
      `;
  });

  return {
    to: "luka@lookat.world, nibi@nyxwolves.com, sidhdharth@nyxwolves.com, rishav@nyxwolves.com, jatin.dhumal.jd@gmail.com",
    // to: "joker4w4k@gmail.com",
    subject: `Daily Stats Update of ${date} `,
    html: htmlContent,
  };
};

const sendOrderConfirmationMail = (email, product, amount) => {
  let htmlContent = `<h1>Order Confirmation</h1>
  <p>Dear Customer,</p>
  <p>Your order has been confirmed:</p>
  <p><strong>Product:</strong> ${product.title}</p>
  <p><strong>Amount:</strong> ${amount}</p>
  <p>Thank you for shopping with us!</p>`;

  return {
    to: email,
    subject: `Order Confirmation`,
    html: htmlContent,
  };
};

const sendDeliveryStatusMail = (email, status) => {
  let htmlContent = `<h1>Delivery Status Confirmation</h1>
  <p>Dear Customer,</p>
  <p>Delivery Status Update:</p>
  <p>We're excited to inform you that your order  has been successfully ${status}! 🚚✨</p>
  <p>Thank you for shopping with us!</p>`;

  return {
    to: email,
    subject: `Delivery Status Confirmation`,
    html: htmlContent,
  };
};

module.exports = {
  transport,
  sendEmail,
  sendHtmlEmail,
  sendHtmlEmailWithCC,
  sendHtmlEmailWithPdf,
  sendDailyStatsMail,
  sendOrderConfirmationMail,
  sendDeliveryStatusMail,
};
